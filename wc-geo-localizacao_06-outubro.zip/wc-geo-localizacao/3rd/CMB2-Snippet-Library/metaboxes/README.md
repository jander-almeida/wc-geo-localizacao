Metaboxes
==========

These are examples of different metabox configurations.