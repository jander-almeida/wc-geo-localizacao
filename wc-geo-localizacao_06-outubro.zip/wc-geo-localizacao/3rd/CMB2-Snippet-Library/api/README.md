CMB2 API Snippets
==========

Snippets related to the CMB2 API endpoints/functionality.
