<?php

/**
 * Handles 'taxonomy_radio_with_image' custom field type.
 */
class DJ_Taxonomy_Radio_With_Image_Display extends CMB2_Display_Taxonomy_Radio {}
