CMB2 Helper Functions
==========

Snippets for working with the [included helper functions](https://github.com/WebDevStudios/CMB2/blob/master/includes/helper-functions.php).

Related CMB2 issues:
* [#130](https://github.com/WebDevStudios/CMB2/issues/130#issuecomment-68160722)
