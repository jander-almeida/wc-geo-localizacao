Options and Settings Pages
==========

These snippets demonstrate how to create options page metaboxes or hook into genesis settings metaboxes.

There are also examples for how you can retrieve an option, using `myprefix_get_option( 'test_text' )`. 

Obviously replace all instances of `myprefix` with a unique project-specific prefix.

[Check these snippets out](https://github.com/WebDevStudios/CMB2-Snippet-Library/tree/master/helper-functions) if you're looking to modify the form output of the `cmb2_metabox_form` function.
