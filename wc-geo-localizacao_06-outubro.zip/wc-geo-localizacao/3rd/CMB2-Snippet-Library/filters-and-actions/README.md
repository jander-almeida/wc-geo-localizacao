CMB2 Filters and Actions
==========

CMB2 has many filters and actions. Included here are snippets which demonstrate some handy ways to use those hooks.